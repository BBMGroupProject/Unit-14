//
//  HomeTableViewController.swift
//  BBMAPP
//
//  Created by user187066 on 4/21/21.
//

import UIKit

class HomeTableViewController: UITableViewController {
    
    let businessName = [("Groomed by Kiel"),("The Tidy Fairies LLC"), ("Rocket City Movers of Huntsville LLC"),("Three Scoops"),("Handel's Homemade Ice Cream"),("J2 Fitness Studio"),("Arsenal Brazilian Jiu-Jitsu")]
    let category = [("Hair/Beauty"),("Cleaning service"),("Cleaning service"),("Food"),("Food"),("Health/Wellness"),("Health/Wellness")]
    let location = [("6275 University Drive #3 Suite 110, Huntsville, AL 35806"),("4702 Joy Cir NW, Huntsville, AL 35810"),("12060 County Line Rd Suite J-212, Madison, Alabama 35758"),("6125 University Drive, Suite C10, Huntsville, AL 35806"),("7086 Hwy 72 W, Huntsville, AL 35806"),("2501 Oakwood Ave NW, Huntsville, AL 35810"),("2801 Governors Dr SW suite a, Huntsville, AL 35805")]
    let des = [("N/A"),("N/A"),("N/A"),("N/A"),("N/A"),("N/A"),("N/A")]
    let imageB = [UIImage(named: "groomed"),
                  UIImage(named: "ttf"),
                   UIImage(named: "rcm"),
                    UIImage(named: "threescoops"),
                     UIImage(named: "handels"),
                     UIImage(named: "j2"),
                       UIImage(named: "arsenal")]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return businessName.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath as IndexPath) as! HomeTableViewCell
        cell.imageCell.largeContentImage = self.imageB[indexPath.row]
        cell.businessLabel.text = self.businessName[indexPath.row]
        cell.categoryLabel.text = self.category[indexPath.row]
        cell.locationLabel.text = self.location[indexPath.row]
        cell.descriptionLabel.text = self.des[indexPath.row]
        
        return cell
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
