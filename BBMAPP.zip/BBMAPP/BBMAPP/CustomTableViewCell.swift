//
//  CustomTableViewCell.swift
//  BBMAPP
//
//  Created by user187066 on 4/21/21.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
 
    lazy var backView: UIView = {
        let view = UIView(frame: CGRect(x: 10, y: 6, width: self.frame.width - 20, height: 110))
        view.backgroundColor = UIColor.green
        return view
    }()
    
    lazy var userImage: UIImageView = {
        let userImage = UIImageView(frame: CGRect(x: 4, y: 4, width: 108, height: 108))
        userImage.contentMode = .scaleAspectFill
        return userImage
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        addSubview(backView)

        // Configure the view for the selected state
        
    }

}
